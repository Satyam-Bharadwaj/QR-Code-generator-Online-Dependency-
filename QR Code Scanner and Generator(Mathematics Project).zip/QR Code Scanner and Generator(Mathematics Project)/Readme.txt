1.The program uses python to generate and read QR codes.
2. Run command $ python "generate.py"
3. Make sure you have enabled import dependencies from the internet or the program will not work.
4. There is a menu which guides you further.

Team
1. Satyam Bharadwaj
2. Siddharth Srinivasan
3. Shreyash Sarnayak
4. Sanjay S S